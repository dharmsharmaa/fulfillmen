<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       www.dhairyasharma.com
 * @since      1.0.0
 *
 * @package    Fulfillmen
 * @subpackage Fulfillmen/admin/partials
 */

global $wpdb;
$prefix = 'fulfillmen_';
$GLOBALS['hide_save_button'] = true;

$APIuserID = get_option($prefix . 'fulfillmen_userID');
$apiKey = get_option($prefix . 'fulfillmen_apikey');
$TrackingUrl = get_option($prefix . 'customtrackingurl');
$iFautoMated = get_option($prefix . 'automation_fw');
$userID = get_option($prefix . 'fulfillmen_username');
$userPass = get_option($prefix . 'fulfillmen_password');
$warehouse = get_option($prefix . 'warehouse_ID');
$ASTIntegration = get_option($prefix . 'ast_integration');

function display_update_plugin_page() {
    if (isset($_POST['update_plugin'])) {
        download_and_install_plugin_update();
    }
    ?>
    <div class="wrap">
        <h1>Update Your Plugin</h1>
        <form method="post">
            <p>Click the button below to update your plugin.</p>
            <input type="submit" name="update_plugin" class="button button-primary" value="Update Plugin">
        </form>
    </div>
    <?php
}