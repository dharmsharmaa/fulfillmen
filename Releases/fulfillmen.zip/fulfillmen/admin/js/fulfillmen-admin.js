(function ($) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	//Functions

	//SKU Sync



	$(function () { // at dom load

		// 1. Inventory Page checkboxes toggle - "Select All" functionality
		jQuery('#allcb').change(function () {
			var isChecked = jQuery(this).prop('checked');
			jQuery('tbody tr td input[type="checkbox"].wf-sku-input-checkbox').prop('checked', isChecked);
			updateSubmitButtonState();
		});

		// 2. Individual checkbox change handler
		jQuery(document).on('change', '.wf-sku-input-checkbox', function() {
			updateSelectAllState();
			updateSubmitButtonState();
		});

		// 3. Form submission with loading state
		jQuery('.syncOrders').on('submit', function(e) {
			var checkedBoxes = jQuery('.wf-sku-input-checkbox:checked').length;
			
			if (checkedBoxes === 0) {
				e.preventDefault();
				alert('Please select at least one order to sync.');
				return false;
			}

			// Add loading state
			var submitButton = jQuery('.wf-sync-sku');
			submitButton.addClass('loading').prop('disabled', true);
			submitButton.text('Syncing Orders...');

			// Show confirmation
			var confirmMessage = 'Are you sure you want to sync ' + checkedBoxes + ' order(s) with Fulfillmen?';
			if (!confirm(confirmMessage)) {
				e.preventDefault();
				// Remove loading state
				submitButton.removeClass('loading').prop('disabled', false);
				submitButton.text('Sync Orders');
				return false;
			}
		});

		// 4. Select2 initialization for enhanced dropdowns
		jQuery(document).ready(function($) {
			if (typeof jQuery.fn.select2 !== 'undefined') {
				jQuery('#shippingChannel').select2({
					placeholder: 'Select shipping channel',
					width: '100%'
				});
				jQuery('#countries').select2({
					placeholder: 'Select countries',
					width: '100%'
				});
			}
		});

		// 5. Enhanced table interactions
		jQuery(document).on('mouseenter', '.widefat tbody tr', function() {
			jQuery(this).addClass('hover-highlight');
		}).on('mouseleave', '.widefat tbody tr', function() {
			jQuery(this).removeClass('hover-highlight');
		});

		// 6. Keyboard shortcuts
		jQuery(document).on('keydown', function(e) {
			// Ctrl/Cmd + A to select all
			if ((e.ctrlKey || e.metaKey) && e.key === 'a' && jQuery('.wf-sku-input-checkbox').length > 0) {
				e.preventDefault();
				jQuery('#allcb').prop('checked', true).trigger('change');
			}
		});

		// Helper functions
		function updateSelectAllState() {
			var totalCheckboxes = jQuery('.wf-sku-input-checkbox').length;
			var checkedCheckboxes = jQuery('.wf-sku-input-checkbox:checked').length;
			
			if (checkedCheckboxes === 0) {
				jQuery('#allcb').prop('indeterminate', false).prop('checked', false);
			} else if (checkedCheckboxes === totalCheckboxes) {
				jQuery('#allcb').prop('indeterminate', false).prop('checked', true);
			} else {
				jQuery('#allcb').prop('indeterminate', true);
			}
		}

		function updateSubmitButtonState() {
			var checkedBoxes = jQuery('.wf-sku-input-checkbox:checked').length;
			var submitButton = jQuery('.wf-sync-sku');
			
			if (checkedBoxes === 0) {
				submitButton.addClass('disabled').prop('disabled', true);
				submitButton.text('Select orders to sync');
			} else {
				submitButton.removeClass('disabled').prop('disabled', false);
				submitButton.text('Sync ' + checkedBoxes + ' Order' + (checkedBoxes !== 1 ? 's' : ''));
			}
		}

		// Initialize on page load
		updateSelectAllState();
		updateSubmitButtonState();

		// 7. Auto-dismiss success/error messages after 5 seconds
		setTimeout(function() {
			jQuery('.apiresponse').not('.error').fadeOut('slow');
		}, 5000);




	});
})(jQuery);
