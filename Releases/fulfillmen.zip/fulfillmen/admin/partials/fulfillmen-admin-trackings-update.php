<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       www.dhairyasharma.com
 * @since      1.0.0
 *
 * @package    Fulfillmen
 * @subpackage Fulfillmen/admin/partials
 */

global $wpdb;
global $woocommerce;
global $post;
$prefix = 'fulfillmen_';
$GLOBALS['hide_save_button'] = true;
$storeName = get_option($prefix . 'fulfillmen_store');
$pushNotification = get_option($prefix . 'push_mailnotification');
$Automation = get_option($prefix . 'automation_fw');
$ASTIntegration = get_option($prefix . 'ff_ast_integration');
$APIuserID = get_option($prefix . 'fulfillmen_userID');
$apiKey = get_option($prefix . 'fulfillmen_apikey');
$TrackingUrl = get_option($prefix . 'customtrackingurl');
$iFautoMated = get_option($prefix . 'automation_fw');
$userID = get_option($prefix . 'fulfillmen_username');
$userPass = get_option($prefix . 'fulfillmen_password');
$warehouse = get_option($prefix . 'warehouse_ID');
$ordersTable = $wpdb->prefix . 'fmOrders';
$credentials = array('custid' => $APIuserID, 'apikey' => $apiKey);
$TrackResponse = '';
$trackingTpye = get_option($prefix . 'tracking_type');
if (empty($trackingTpye)) {
    $trackingTpye = 1;
}

function add_tracking_information_into_order($order, $tracking_details)
{

    $args = array(
        'tracking_provider' => $tracking_details['carrier'],
        'tracking_number' => wc_clean($tracking_details['tracking_number']),
        'date_shipped' => wc_clean($tracking_details['ship_date']),
        'status_shipped' => '',
    );
    update_post_meta($order, '_tracking_provider', $args['tracking_provider']);
    update_post_meta($order, '_tracking_number', $args['tracking_number']);
    update_post_meta($order, '_date_shipped', $args['date_shipped']);

    $order = wc_get_order($order);
    if ($order) {
        $meta_key = '_tracking_provider';
        $new_value = $args['tracking_provider'];
        $order->update_meta_data($meta_key, $new_value);
        $order->save();

        $meta_key = '_tracking_number';
        $new_value = $args['tracking_number'];
        $order->update_meta_data($meta_key, $new_value);
        $order->save();

        $meta_key = '_date_shipped';
        $new_value = $args['date_shipped'];
        $order->update_meta_data($meta_key, $new_value);
        $order->save();
    }

}
if ($Automation == "yes") {
    $args = array(
        'post_type' => 'shop_order',
        'post_status' => array('wc-processing'),
        'posts_per_page' => 500,
    );
    $loop = new WP_Query($args);
    if ($loop->have_posts()):
        while ($loop->have_posts()): $loop->the_post();

            $orderNUmberFromPost = $loop->post->ID;
            $orderNUmber = new WC_Order($orderNUmberFromPost);
            $orderNUmber = trim(str_replace('#', '', $orderNUmber->get_order_number()));
            $orderid = $orderNUmber;
            $postId = $orderNUmberFromPost;
            if (strpos($orderid, $storeName) == false) {
                $orderidforJSON = $orderid . "%20" . $storeName;
            } else {
                $orderidforJSON = $orderid;
            }
            $OrderInfo = file_get_contents('http://wms.fulfillmen.com/api-json/GetOrderList.aspx?Key=' . $apiKey . '&page=1&CsRefNo=' . $orderidforJSON);
            $jData = json_decode($OrderInfo, true);
            $dataArr = $jData['data'];
            if (!empty($dataArr[0]['TrackingNo'])) {
                $orderStatus = intval($dataArr[0]['OrderStatus']);
                if ($orderStatus == 6) {
                    // $fmtracking = $dataArr[0]['TrackingNo'];
                    if ($trackingTpye == 1) {
                        $fmtracking = $dataArr[0]['TrackingNo'];
                    } else {
                        if (isset($dataArr[0]['TransitNumber'])) {
                            $fmtracking = $dataArr[0]['TransitNumber'];
                        } else {
                            $fmtracking = $dataArr[0]['TrackingNo'];
                        }
                        // $fmtracking = $dataArr[0]['TransitNumber'];
                    }
                    // Determine provider and date shipped if available
                    $provider = isset($dataArr[0]['Carrier']) && !empty($dataArr[0]['Carrier']) ? $dataArr[0]['Carrier'] : 'Fulfillmen';
                    $date_shipped = isset($dataArr[0]['DateShipped']) && !empty($dataArr[0]['DateShipped']) ? $dataArr[0]['DateShipped'] : date('Y-m-d');

                    if ($ASTIntegration == "yes" && class_exists('WC_Advanced_Shipment_Tracking_Actions')) {
                        try {
                            $wast = WC_Advanced_Shipment_Tracking_Actions::get_instance();
                            $args = array(
                                'tracking_provider' => $provider,
                                'tracking_number' => $fmtracking,
                                'date_shipped' => $date_shipped,
                                'status_shipped' => 1,
                            );
                            $wast->insert_tracking_item($postId, $args);
                        } catch (Exception $e) {
                            echo "<p style='color: #dc3545;'>Error with Advanced Shipment Tracking: " . $e->getMessage() . "</p>";
                        }
                    }
                    // Standard WooCommerce tracking
                    try {
                        $WCorder = new WC_Order($postId);
                        $WCorder->update_status('wc-completed');
                        $tracking_details = array('carrier' => $provider, 'tracking_number' => $fmtracking, 'ship_date' => $date_shipped);
                        add_tracking_information_into_order($postId, $tracking_details);
                    } catch (Exception $e) {
                        echo "<p style='color: #dc3545;'>Error updating order: " . $e->getMessage() . "</p>";
                    }

                    $sql = "UPDATE $ordersTable SET FMOrderStatus = 'Fulfilled', FMOrderTracking =' $fmtracking'  WHERE OrderNumber = '$orderid'";
                    $wpdb->query($sql);
                    update_post_meta($postId, '_postnord_field_data', sanitize_text_field($fmtracking));
                    //update_post_meta($postId, '_tracking_number', sanitize_text_field($fmtracking));

                    $TrackResponse .= $orderid . "Tracking: " . $fmtracking . "\n";

                    if ($pushNotification == 'yes' && class_exists('WC_Email_Customer_Completed_Order')) {
                        $WCorder = function_exists('wc_get_order') ? wc_get_order($postId) : null;
                        if ($WCorder) {
                            $note = sprintf(
                                'Order shipped via %s. Tracking Number: %s. Date Shipped: %s.',
                                $provider,
                                $fmtracking,
                                $date_shipped
                            );
                            $WCorder->add_order_note($note, false, false);
                            // Also trigger the completed order email with tracking info
                            $email_oc = new WC_Email_Customer_Completed_Order();
                            $email_oc->trigger($postId);
                        }
                    }
                }
            }

        endwhile;
    wp_reset_query();
    endif;
} else {
    echo '<div class="notice notice-error"><p><strong>Authentication Error:</strong> Invalid username and/or password. Please check your Fulfillmen credentials in the settings.</p></div>';
    $TrackResponse .= "\n Automation is disabled";
}
