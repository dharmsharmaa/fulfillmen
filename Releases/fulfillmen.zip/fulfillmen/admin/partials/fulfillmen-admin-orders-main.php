<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       www.dhairyasharma.com
 * @since      1.0.0
 *
 * @package    Fulfillmen
 * @subpackage Fulfillmen/admin/partials
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    echo '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Error: Direct Access Not Allowed</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; max-width: 800px; margin: 50px auto; padding: 20px; }
            .error-box { background-color: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 15px; border-radius: 5px; }
            h1 { color: #721c24; }
            .solution { margin-top: 20px; background-color: #e9ecef; padding: 15px; border-radius: 5px; }
        </style>
    </head>
    <body>
        <div class="error-box">
            <h1>Error: Direct Access Not Allowed</h1>
            <p>This file cannot be accessed directly. It is part of the Fulfillmen plugin and must be accessed through WordPress admin.</p>
        </div>
        <div class="solution">
            <h2>How to fix:</h2>
            <p>This error occurs when accessing the file directly rather than through WordPress admin. To use this plugin:</p>
            <ol>
                <li>Access your WordPress admin dashboard</li>
                <li>Navigate to WooCommerce &gt; Settings &gt; Fulfillmen</li>
                <li>Use the plugin through the WordPress admin interface</li>
            </ol>
        </div>
        <p>If you continue to see errors, please contact your site administrator or the plugin author for support.</p>
    </body>
    </html>';
    exit;
}

global $wpdb;
$prefix = 'fulfillmen_';
$GLOBALS['hide_save_button'] = true;
global $woocommerce;
global $post;
$storeName = get_option($prefix . 'fulfillmen_store');
$APIuserID = get_option($prefix . 'fulfillmen_userID');
$apiKey = get_option($prefix . 'fulfillmen_apikey');
$TrackingUrl = get_option($prefix . 'customtrackingurl');
$iFautoMated = get_option($prefix . 'automation_fw');
$userID = get_option($prefix . 'fulfillmen_username');
$userPass = get_option($prefix . 'fulfillmen_password');
$warehouse = get_option($prefix . 'warehouse_ID');
$ordersTable = $wpdb->prefix . 'fmOrders';
$shippingConfig = $wpdb->prefix . 'fmSetShipping';
$orderMode = get_option($prefix . 'order_mode'); //1 warehouse 2 dropship
$processAllOrders = get_option($prefix . 'process_all_geos');
$wildcardChannel = get_option($prefix . 'wildcard_channel');
if($processAllOrders == 'yes') {
    $processAllFlag = 1;
} else {
    $processAllFlag = 0;
}


function wf_process_orders($orderid, string $apiurl, array $credentials, $storeSuffix, $orderMode)
{
    global $prefix;
    global $wpdb;
    global $woocommerce;
    global $post;
    global $warehouse;
    global $wildcardChannel;

    
    global  $processAllFlag;
   
    $prefix = 'fulfillmen_';
    $shippingConfig = $wpdb->prefix . 'fmSetShipping';
    $ordersTable = $wpdb->prefix . 'fmOrders';
    $storeName = $storeSuffix;
    $order = wc_get_order($orderid);
    foreach ($order->get_items() as $item_key => $item) {
        $item_id = $item->get_id();
        $item_data = $item->get_data();
        $product_name = $item_data['name'];
        $product_id = $item_data['product_id'];
        $variation_id = $item_data['variation_id'];
        $quantity = $item_data['quantity'];
        $tax_class = $item_data['tax_class'];
        $line_subtotal = $item_data['subtotal'];
        $line_subtotal_tax = $item_data['subtotal_tax'];
        $line_total = $item_data['total'];
        $line_total_tax = $item_data['total_tax'];

        
        $productobj = $variation_id ? wc_get_product($variation_id) : wc_get_product($product_id);
        $image_id = $productobj->is_type('variable') ? $productobj->get_variation_image_id($variation_id) : $productobj->get_image_id();

       

        $productbyid = wc_get_product($product_id);
        $image_id = $productbyid->get_image_id();
        $image_url = wp_get_attachment_image_url($image_id, 'full');
        $imgurl = preg_replace("~^(https?://)~", "", $image_url) ?: "";

      
        //$product = $item->get_product(); // Get the WC_Product object
        //$product_type = $product->get_type();
        //$product_sku = $product->get_sku();
        /*$product_variation_id = $variation_id;
        if ($product_variation_id) {
            $product = new WC_Product($variation_id);
        } else {
            $product = $item->get_product();
        }*/
        

        $product = $item->get_product();
        $product_sku = $product->get_sku();
        $product_price = $product->get_price();
        $stock_quantity = $product->get_stock_quantity();
        $pprice = number_format(floatval($product_price), 2);
        $priceSanitised = str_replace(',', '', $pprice);
        $product_weight = "0.100";
        if($orderMode == 2) {
            $product_info[] = [
                "SKU" => $product_sku,
                "EnName" => $product_name,
                "CnName" => "太阳镜",
                "Quantity" => $quantity,
                "Weight" => number_format(floatval($product_weight), 2),
                "Price" => $priceSanitised,
                "ProducingArea" => "CN",
                "HSCode" => "000000",
                "Currency" => "USD",
                "Material" => "",
                "Application" => "",
                "SalesAddress" => $imgurl
             ] ;
        } else {
            $product_info[] = [
                "SKU" => $product_sku,
                "EnName" => $product_name,
                "CnName" => "太阳镜",
                "Quantity" => $quantity,
                "Weight" => number_format(floatval($product_weight), 2),
                "Price" => $priceSanitised,
                "ProducingArea" => "CN",
                "HSCode" => "000000",
                "Currency" => "USD",
                "Material" => "",
                "Application" => "",
                "SalesAddress" => ""
             ] ;
        }
       
    }

    ## SHIPPING INFORMATION:
    $order_number = $order->get_order_number();
    $order_shipping_name = $order->get_formatted_shipping_full_name();
    $order_shipping_company = $order->get_shipping_company();
    $order_shipping_address_1 = $order->get_shipping_address_1();
    $order_shipping_address_2 = $order->get_shipping_address_2();
    $order_shipping_city = $order->get_shipping_city();
    $order_shipping_country = $order->get_shipping_country(); //WC()->countries->countries[$order->get_billing_country()];
    //$order_shipping_state = WC()->countries->get_states($order_shipping_country)[$order->get_shipping_state()]; //$order->get_shipping_state();;
    $order_shipping_state = $order->get_shipping_state();
    $order_shipping_postcode = $order->get_shipping_postcode();
    $order_billing_email = $order->get_billing_email();
    $order_customer_note = $order->get_customer_note();
    $order_billing_phone = $order->get_billing_phone();
    $csRef = $order_number . " " . $storeName;
    $getChannel = $wpdb->get_results("SELECT ChannelID from $shippingConfig where CountryID='$order_shipping_country' ORDER BY id DESC LIMIT 1");
    foreach ($getChannel as $channel) {
        $shippingChannel = $channel->ChannelID;
    }
    if (empty($shippingChannel)) {
        $shippingChannel = $wildcardChannel; //'CHINAPOST';
    }

    $params = [
        "Style" => get_option($prefix . 'order_mode'),
        "CustomerID" => $credentials['custid'],
        "ShippingCode" => $shippingChannel, //add channel code var here
        "ShipToName" => $order_shipping_name,
        "ShipToPhoneNumber" => $order_billing_phone,
        "ShipToMobileNumber" => $order_billing_phone,
        "ShipToCountry" => $order_shipping_country,
        "ShipToState" => $order_shipping_state,
        "ShipToCity" => $order_shipping_city,
        "ShipToArea" => "",
        "ShipToAdress1" => $order_shipping_address_1,
        "ShipToAdress2" => $order_shipping_address_2,
        "ShipToHouseNo" => "",
        "ShipToZipCode" => $order_shipping_postcode,
        "ShipToCompanyName" => $order_shipping_company,
        "ShipToEmail" => $order_billing_email,
        "SendName" => "",
        "SendCountry" => "China",
        "SendState" => "Guangdong",
        "SendCity" => "Shenzhen",
        "SendAddress" => "Huizhou",
        "SendZipcode" => "518000",
        "SendContact" => "",
        "SendCompanyName" => "NA",
        "SendEmail" => "",
        "OrderStatus" => "1",
        "TrackingNo" => "",
        "CusRemark" => "",
        "CODType" => "",
        "CODMoney" => "",
        "IOSS" => "",
        "VATNo" => "",
        "IDCardNo" => "",
        "CsRefNo" => $csRef,
        "WarehouseId" => "536",
        "CustWeight" => "0.100",
        "FLength" => "1",
        "FWidth" => "1",
        "FHeight" => "1",
        "Products" => $product_info,
     ];
    // var_dump($params);
    //changed to REST

    $params = json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $response  = wp_remote_post($apiurl, array(
        'headers'     => array('Content-Type' => 'application/json; charset=utf-8'),
        'body'        => $params,
        'method'      => 'POST',
        'data_format' => 'body',
    ));
    $body = wp_remote_retrieve_body($response);
    //var_dump($body);
    $responseArr = ["Body" => $body, "debug" => $apiurl . " req: " . $params];
    return $responseArr;
}

if (!empty($userID && $userPass)) {
    echo "<div class='fulfillmen-admin-page'>";
    echo "<div class='notice notice-info' style='margin: 10px 0;'><p><strong>Fulfillmen Plugin Updated:</strong> Version 1.3.5 includes improved pagination, better handling of synced orders, and UI enhancements.</p></div>";
    echo "<h3>Sync Pending Orders with Fulfillmen</h3>";
    if (!empty($_POST)) {
        //Sending the data to FUlfillmen
        //var_dump($_POST);
        foreach ($_POST['data'] as $row) {
            // If the checkbox is on
            if (isset($row['select'])) {
                $orderid = $row['orderID'];
                $postID = $row['postID'];
                $credentials = array('custid' => $APIuserID, 'apikey' => $apiKey);

                $response = wf_process_orders($orderid, "https://wms.fulfillmen.com/api-json/CreateOrder.aspx?Key=$apiKey", $credentials, $storeName, $orderMode);

                if (is_wp_error($response)) {
                    echo json_encode(array('success' => $response->get_error_message()));
                } else {
                    $res = json_decode($response['Body']);
                    // var_dump($response);
                    // var_dump($res);
                    if ($res->success == "success") {
                        //echo json_encode(array('code' => $res->success, 'status' => $res->success, 'order'=> $res->OrderNo, 'reference'=> $res->CsRefNo));
                        echo "<div class='apiresponse'><strong>✓ Order Processed Successfully:</strong> " . $res->OrderNo . " - " . $res->message . "</div>";
                        $sql = "INSERT INTO $ordersTable (OrderNumber,FulfillmenOrderNum,FMOrderStatus,FMOrderTracking,isSynced) values('$res->CsRefNo','$res->OrderNo','Draft','NA','0')";
                        $wpdb->query($sql);
                        //$WCorder = new WC_Order($orderid);
                        //$WCorder->update_status('wc-processing');
                        $metaUpdate1 = update_post_meta($postID, 'fmDraftSynced', 'yes');
                        $metaUpdate2 = update_post_meta($postID, 'fmDraftOrderNumber', $res->OrderNo);
                        if( $metaUpdate1 == false ||  $metaUpdate2 == false){
                            echo "<div class='apiresponse error'>⚠ Warning: Can't update the post meta for Post ID: $postID</div>";
                        }
                        $order = wc_get_order($orderid);
                        if ($order) {
                            $meta_key = 'fmDraftSynced';
                            $new_value = 'yes';
                            $order->update_meta_data($meta_key, $new_value);
                            $order->save();

                            $meta_key = 'fmDraftOrderNumber';
                            $new_value = $res->OrderNo;
                            $order->update_meta_data($meta_key, $new_value);
                            $order->save();
                        
                            //echo "Order metadata updated successfully!";
                        } else {
                            echo "<div class='apiresponse error'>⚠ Warning: Can't update the post meta for Post ID: $postID</div>";
                        }
                    } else {
                        $debugresp = $response['debug'];
                        echo "<div class='apiresponse error'><strong>❌ Error Occurred:</strong><br>";
                        echo "Order Mode: " . get_option($prefix . 'order_mode') . "<br>";
                        echo "Code: " . $res->code . "<br>";
                        echo "Message: " . $res->message . "<br>";
                        if (isset($res->Enmessage)) echo "Details: " . $res->Enmessage . "<br>";
                        echo "<details><summary>Debug Info (Click to expand)</summary><pre>$debugresp</pre></details>";
                        echo "</div>";
                    }
                    //echo json_encode(array('code' => $res, 'status' => $res, 'order'=>$res->OrderNo, 'message' => __($msg)));
                }

                //wp_die();
            } /*else {
        echo 'Error: Please select at least one order to Sync! <br>';

        }*/
        }
        //here ends the for each loop
        echo "<br><a href='#' onclick='history.go(-1);' class='button-secondary'>Back</a>";
    } else {
        $getConfiguredCountries =  $wpdb->get_results("SELECT CountryID from $shippingConfig");

        foreach ($getConfiguredCountries as $countries) {
            $configCountries[] = $countries->CountryID;
        }

        //Printing the Form
        echo '<div class="sync-toggle-controls">';
        echo '<input type="checkbox" id="showSyncedOrders" ' . (isset($_GET['show_synced']) ? 'checked' : '') . '>';
        echo '<label for="showSyncedOrders">Show already synced orders (read-only)</label>';
        echo '</div>';
        
        echo '<form class="syncOrders" action="" method="post"> ';
        echo '<table class="wp-list-table widefat fixed striped posts">';
        echo '<thead><tr>';
        echo '<th class="manage-column column-cb check-column" style="padding:8px 10px;"><input type="checkbox" id="allcb"></th>';
        echo '<th>Order Number</th>';
        echo '<th>Order Date</th>';
        echo '<th>Sync Status</th>';
        echo '</tr></thead>';
        echo '<tbody>';

        if (isset($_GET['paged'])) {
            $paged = intval($_GET['paged']);
        } else {
            $paged = 1;
        }

        $per_page = 25;
        $offset = ($paged - 1) * $per_page;
        
        // Check if we should show synced orders
        $showSyncedOrders = isset($_GET['show_synced']) && $_GET['show_synced'] == '1';

        // Check if HPOS is enabled - this ensures compatibility with both HPOS and legacy post-based orders
        $hpos_enabled = function_exists('wc_get_order_types') && get_option('woocommerce_custom_orders_table_enabled') === 'yes';

        // Use WC_Order_Query for both HPOS and legacy orders - WooCommerce handles the compatibility internally
        
        // Build meta query - always get all orders, we'll filter after fetching
        $meta_query = array(); // Get all processing orders
        
        // First, get total count for pagination
        $count_args = array(
            'status'         => 'processing',
            'limit'          => -1,
            'return'         => 'ids',
        );

        // Fallback for older WooCommerce versions that might not support WC_Order_Query properly
        if (class_exists('WC_Order_Query')) {
            $count_query = new WC_Order_Query($count_args);
            $all_order_ids = $count_query->get_orders();
        } else {
            // Legacy fallback using WP_Query for very old WC versions
            $legacy_args = array(
                'post_type' => 'shop_order',
                'post_status' => 'wc-processing',
                'posts_per_page' => -1,
                'fields' => 'ids'
            );
            $legacy_query = new WP_Query($legacy_args);
            $all_order_ids = $legacy_query->posts;
        }
        
        // Filter orders based on sync status
        $filtered_orders = array();
        foreach ($all_order_ids as $order_id) {
            // Get the order object from the ID
            $order = wc_get_order($order_id);
            
            if ($order) {
                $fmDraftSynced = $order->get_meta('fmDraftSynced');
                $fmDraftOrderNumber = $order->get_meta('fmDraftOrderNumber');
                $isAlreadySynced = ($fmDraftSynced === 'yes' && !empty($fmDraftOrderNumber));
            
                if ($showSyncedOrders || !$isAlreadySynced) {
                    $filtered_orders[] = $order;
                }
            }
        }
        
        $total_orders = count($filtered_orders);
        
        $max_pages = ceil($total_orders / $per_page);

        // Now get the actual orders for this page from the filtered list
        $orders = array_slice($filtered_orders, $offset, $per_page);
        if ($orders) {
            foreach ($orders as $order) {
                $orderNUmberFromPost = $order->get_id();
                $order_number = trim(str_replace('#', '', $order->get_order_number()));
                $order_shipping_country = $order->get_shipping_country();

                if (in_array($order_shipping_country, $configCountries) || $processAllFlag == 1) {
                    // Check if order is already synced
                    $fmDraftSynced = $order->get_meta('fmDraftSynced');
                    $fmDraftOrderNumber = $order->get_meta('fmDraftOrderNumber');
                    $isAlreadySynced = ($fmDraftSynced === 'yes' && !empty($fmDraftOrderNumber));
                    
                    if ($isAlreadySynced) {
                        // Show synced orders as disabled/grayed out
                        echo '<tr class="already-synced">';
                        echo '<td><input type="checkbox" disabled style="cursor: not-allowed;" title="Already synced with Fulfillmen"></td>';
                        echo '<td>' . $order_number . ' <small style="color: #666;">(FM Order: ' . htmlspecialchars($fmDraftOrderNumber) . ')</small></td>';
                        echo '<td>' . $order->get_date_created()->format('Y-m-d H:i:s') . '</td>';
                        echo '<td class="order_status column-order_status"><span class="order-status synced">✓ Synced</span></td>';
                        echo '</tr>';
                    } else {
                        // Show unsynced orders as normal (available for sync)
                        echo '<tr>';
                        echo '<td><input type="checkbox" name="data[' . $order_number . '][select]" class="wf-sku-input-checkbox" id="' . $order_number . '"></td>';
                        echo '<td>' . $order_number . '</td>';
                        echo '<td>' . $order->get_date_created()->format('Y-m-d H:i:s') . '</td>';
                        echo '<td class="order_status column-order_status"><span class="order-status status-processing">Ready to Sync</span></td>';
                        echo '<input type="hidden" name="data[' . $order_number . '][orderID]" value="' . $order_number . '">';
                        echo '<input type="hidden" name="data[' . $order_number . '][postID]" value="' . $orderNUmberFromPost . '">';
                        echo '</tr>';
                    }
                }
            }
            echo '</tbody>';
            echo '</table>';

            echo '<button type="submit" class="wf-sync-sku button-primary" >Sync Orders</button>';
            echo '</form>';

            echo '<br>';
            
            // Display pagination info
            $start_item = (($paged - 1) * $per_page) + 1;
            $end_item = min($paged * $per_page, $total_orders);
            echo '<div class="tablenav-pages">';
            echo '<span class="displaying-num">' . sprintf('Showing %d to %d of %d orders', $start_item, $end_item, $total_orders) . '</span>';
            
            // Build pagination links
            echo '<div class="pagination-links">';
            
            $base_url = 'admin.php?page=wc-settings&tab=fulfillmen&section=orders';
            $show_synced_param = $showSyncedOrders ? '&show_synced=1' : '';
            
            // Previous button
            if ($paged > 1) {
                $prevpage = $paged - 1;
                echo '<a class="pagiantion-link prev-page" href="' . $base_url . '&paged=' . $prevpage . $show_synced_param . '">‹ Previous</a>';
            }
            
            // Page numbers
            $start_page = max(1, $paged - 2);
            $end_page = min($max_pages, $paged + 2);
            
            // Show first page if we're not showing it
            if ($start_page > 1) {
                echo '<a class="pagiantion-link" href="' . $base_url . '&paged=1' . $show_synced_param . '">1</a>';
                if ($start_page > 2) {
                    echo '<span class="pagination-dots">...</span>';
                }
            }
            
            // Show page numbers around current page
            for ($i = $start_page; $i <= $end_page; $i++) {
                if ($i == $paged) {
                    echo '<span class="pagiantion-link current">' . $i . '</span>';
                } else {
                    echo '<a class="pagiantion-link" href="' . $base_url . '&paged=' . $i . $show_synced_param . '">' . $i . '</a>';
                }
            }
            
            // Show last page if we're not showing it
            if ($end_page < $max_pages) {
                if ($end_page < $max_pages - 1) {
                    echo '<span class="pagination-dots">...</span>';
                }
                echo '<a class="pagiantion-link" href="' . $base_url . '&paged=' . $max_pages . $show_synced_param . '">' . $max_pages . '</a>';
            }
            
            // Next button
            if ($paged < $max_pages) {
                $nextpage = $paged + 1;
                echo '<a class="pagiantion-link next-page" href="' . $base_url . '&paged=' . $nextpage . $show_synced_param . '">Next ›</a>';
            }
            
            echo '</div>'; // Close pagination-links
            echo '</div>'; // Close tablenav-pages
        } else {
            echo '</tbody>';
            echo '</table>';
            echo '<div class="fulfillmen-notice warning">';
            echo '<p>No orders found that need to be synced.</p>';
            echo '</div>';
        }

    }
    echo "</div>"; // Close fulfillmen-admin-page
} else {
    echo "<div class='fulfillmen-admin-page'>";
    echo "<div class='fulfillmen-notice error'>";
    echo "<h3>❌ Authentication Error</h3>";
    echo "<p>Invalid Username and/or Password! Please check your Fulfillmen credentials in the settings.</p>";
    echo "</div>";
    echo "</div>";
}
