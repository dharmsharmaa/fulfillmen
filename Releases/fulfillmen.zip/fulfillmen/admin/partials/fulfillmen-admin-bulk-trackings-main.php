<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       www.dhairyasharma.com
 * @since      1.0.0
 *
 * @package    Fulfillmen
 * @subpackage Fulfillmen/admin/partials
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define the template URL
// Get the plugin URL using WordPress functions
$plugin_url = plugin_dir_url(dirname(dirname(__FILE__)));
$template_url = $plugin_url . 'assets/tracking-template.csv';
// Ensure no trailing slashes cause issues with the URL
$template_url = esc_url(trailingslashit($plugin_url) . 'assets/tracking-template.csv');

global $wpdb;
global $woocommerce;
global $post;
$prefix = 'fulfillmen_';
$GLOBALS['hide_save_button'] = true;

$storeName = get_option($prefix . 'fulfillmen_store');
$pushNotification = get_option($prefix . 'push_mailnotification');
$ASTIntegration = get_option($prefix . 'ff_ast_integration');
$Automation = get_option($prefix . 'automation_fw');
$APIuserID = get_option($prefix . 'fulfillmen_userID');
$apiKey = get_option($prefix . 'fulfillmen_apikey');
$TrackingUrl = get_option($prefix . 'customtrackingurl');
$iFautoMated = get_option($prefix . 'automation_fw');
$userID = get_option($prefix . 'fulfillmen_username');
$userPass = get_option($prefix . 'fulfillmen_password');
$warehouse = get_option($prefix . 'warehouse_ID');
$ordersTable = $wpdb->prefix . 'fmOrders';

/**
 * Add tracking information to an order
 * 
 * @param int|WC_Order $order Order ID or order object
 * @param array $tracking_details Array with carrier, tracking_number, ship_date
 * @return bool Success or failure
 */
function add_tracking_information_into_order($order, $tracking_details)
{
    // Get the order ID if an object was passed
    $order_id = is_object($order) && method_exists($order, 'get_id') ? $order->get_id() : $order;
    
    // Clean values if wc_clean exists
    $tracking_number = function_exists('wc_clean') ? wc_clean($tracking_details['tracking_number']) : sanitize_text_field($tracking_details['tracking_number']);
    $date_shipped = !empty($tracking_details['ship_date']) ? 
        (function_exists('wc_clean') ? wc_clean($tracking_details['ship_date']) : sanitize_text_field($tracking_details['ship_date'])) : 
        date('Y-m-d');
    
    $args = array(
        'tracking_provider' => $tracking_details['carrier'],
        'tracking_number' => $tracking_number,
        'date_shipped' => $date_shipped,
        'status_shipped' => '',
    );
    
    // Update post meta
    $success = true;
    $success = $success && update_post_meta($order_id, '_tracking_provider', $args['tracking_provider']);
    $success = $success && update_post_meta($order_id, '_tracking_number', $args['tracking_number']);
    $success = $success && update_post_meta($order_id, '_date_shipped', $args['date_shipped']);
    
    return $success;
}

/**
 * Process tracking information for an order
 * 
 * @param int $order_id Order ID
 * @param string $orderNum Original order number
 * @param string $trackingNum Tracking number
 * @param string $provider Tracking provider
 * @param string $date_shipped Date shipped (YYYY-MM-DD)
 * @param string $status Status
 * @param string $notes Notes
 */
function processOrderTracking($order_id, $orderNum, $trackingNum, $provider, $date_shipped, $status, $notes) {
    global $wpdb, $ordersTable, $ASTIntegration, $pushNotification;
    
    // Initialize tracking counters if not set
    if (!isset($GLOBALS['fm_tracking_success'])) {
        $GLOBALS['fm_tracking_success'] = 0;
    }
    if (!isset($GLOBALS['fm_tracking_failure'])) {
        $GLOBALS['fm_tracking_failure'] = 0;
    }
    
    $success = false;
    
    echo "<div class='tracking-update' style='margin-bottom: 10px; padding: 10px; background: #f8f9fa; border-left: 4px solid #007bff;'>
        <strong>Processing Order #{$orderNum}</strong><br>
        Tracking: {$trackingNum}<br>
        Provider: {$provider}<br>
        Date: {$date_shipped}
    </div>";
    
    if (!empty($trackingNum)) {
        // Try Advanced Shipment Tracking plugin if available
        if ($ASTIntegration == "yes" && class_exists('WC_Advanced_Shipment_Tracking_Actions')) {
            try {
                $wast = WC_Advanced_Shipment_Tracking_Actions::get_instance();
                $args = array(
                    'tracking_provider' => $provider,
                    'tracking_number' => $trackingNum,
                    'date_shipped' => $date_shipped,
                    'status_shipped' => 1,
                );
                $wast->insert_tracking_item($order_id, $args);
                $success = true;
            } catch (Exception $e) {
                echo "<p style='color: #dc3545;'>Error with Advanced Shipment Tracking: " . $e->getMessage() . "</p>";
            }
        } else {
            // Standard WooCommerce tracking
            try {
                if (function_exists('wc_get_order')) {
                    $WCorder = wc_get_order($order_id);
                    if ($WCorder) {
                        // Update order status to completed
                        $WCorder->update_status('wc-completed');
                        
                        // Add notes if provided
                        if (!empty($notes)) {
                            $WCorder->add_order_note($notes, false, false);
                        }
                        
                        // Add tracking details
                        $tracking_details = array(
                            'carrier' => $provider,
                            'tracking_number' => $trackingNum,
                            'ship_date' => $date_shipped
                        );
                        add_tracking_information_into_order($order_id, $tracking_details);
                        $success = true;
                    }
                } else {
                    // Fallback if wc_get_order doesn't exist
                    if (function_exists('update_post_meta')) {
                        update_post_meta($order_id, '_tracking_provider', $provider);
                        update_post_meta($order_id, '_tracking_number', $trackingNum);
                        update_post_meta($order_id, '_date_shipped', $date_shipped);
                        $success = true;
                    }
                }
            } catch (Exception $e) {
                echo "<p style='color: #dc3545;'>Error updating order: " . $e->getMessage() . "</p>";
            }

            // Always try to update our plugin's tracking table if order exists there
            try {
                $sql = "UPDATE $ordersTable SET FMOrderStatus = 'Fulfilled', FMOrderTracking =' $trackingNum' WHERE OrderNumber = '$order_id' OR OrderNumber LIKE '%$orderNum%'";
                $wpdb->query($sql);
                
                // Update order meta for custom tracking display if possible
                if (function_exists('update_post_meta')) {
                    update_post_meta($order_id, '_postnord_field_data', sanitize_text_field($trackingNum));
                }
                
                // Send notification email if enabled
                if ($pushNotification == 'yes' && class_exists('WC_Email_Customer_Completed_Order')) {
                    $email_oc = new WC_Email_Customer_Completed_Order();
                    $email_oc->trigger($order_id);
                }
                
                // Mark as success even if only the database update worked
                $success = true;
            } catch (Exception $e) {
                echo "<p style='color: #dc3545;'>Error updating database: " . $e->getMessage() . "</p>";
            }
        }
    }
    
    // Update success/failure count
    if ($success) {
        $GLOBALS['fm_tracking_success']++;
        echo "<p style='color: #28a745;'><strong>✓ Success:</strong> Tracking information updated for order #{$orderNum}</p>";
    } else {
        $GLOBALS['fm_tracking_failure']++;
        echo "<p style='color: #dc3545;'><strong>✗ Failed:</strong> Could not update tracking for order #{$orderNum}</p>";
    }
}

// Custom error logger function
function fm_log_error($message, $data = array()) {
    echo '<div class="fm-error-log" style="background: #f8d7da; border: 1px solid #f5c6cb; border-left: 5px solid #721c24; color: #721c24; padding: 15px; margin: 15px 0; border-radius: 3px;">';
    echo '<h3 style="margin-top: 0;">Error Details</h3>';
    echo '<p><strong>Message:</strong> ' . esc_html($message) . '</p>';
    
    if (!empty($data)) {
        echo '<p><strong>Debug Information:</strong></p>';
        echo '<pre style="background: #f1f1f1; padding: 10px; overflow: auto; max-height: 300px;">';
        if (is_array($data) || is_object($data)) {
            print_r($data);
        } else {
            echo esc_html($data);
        }
        echo '</pre>';
    }
    
    // Add PHP version and memory information
    echo '<p><strong>System Info:</strong> PHP ' . phpversion() . ' | Memory: ' . ini_get('memory_limit') . '</p>';
    echo '</div>';
}

/**
 * Validate the CSV file content for common issues
 * 
 * @param string $file_path Path to the CSV file
 * @return array Array with 'valid' boolean and 'errors' array
 */
function fm_validate_csv($file_path) {
    $result = array(
        'valid' => true,
        'errors' => array(),
        'details' => array()
    );
    
    if (!file_exists($file_path)) {
        $result['valid'] = false;
        $result['errors'][] = "File does not exist: $file_path";
        return $result;
    }
    
    if (!is_readable($file_path)) {
        $result['valid'] = false;
        $result['errors'][] = "File is not readable: $file_path";
        return $result;
    }
    
    $handle = @fopen($file_path, 'r');
    if ($handle === false) {
        $result['valid'] = false;
        $result['errors'][] = "Could not open file: $file_path";
        return $result;
    }
    
    // Check first few lines of the file to identify common issues
    $line_count = 0;
    $headers = array();
    $sample_data = array();
    
    while (($line = fgetcsv($handle)) !== false && $line_count < 5) {
        if ($line_count === 0) {
            // First line should be headers
            $headers = array_map('strtolower', array_map('trim', $line));
            
            // Check for empty headers
            if (count(array_filter($headers)) !== count($headers)) {
                $result['valid'] = false;
                $result['errors'][] = "CSV contains empty column headers. Please ensure all columns have names.";
            }
            
            // Check for required headers
            $required = array('ordernumber', 'trackingid');
            $missing = array();
            
            foreach ($required as $req) {
                if (!in_array($req, $headers)) {
                    $missing[] = $req;
                }
            }
            
            if (!empty($missing)) {
                $result['valid'] = false;
                $result['errors'][] = "Required columns missing: " . implode(', ', $missing);
            }
            
            $result['details']['headers'] = $headers;
        } else {
            // Sample data rows
            $sample_data[] = $line;
            
            // Check for row length mismatch
            if (count($line) !== count($headers)) {
                $result['valid'] = false;
                $result['errors'][] = "Row {$line_count} has " . count($line) . " columns but should have " . count($headers) . " columns. Check for extra commas or missing fields.";
            }
        }
        
        $line_count++;
    }
    
    if ($line_count === 0) {
        $result['valid'] = false;
        $result['errors'][] = "CSV file is empty or not formatted correctly.";
    } else if ($line_count === 1) {
        $result['valid'] = false;
        $result['errors'][] = "CSV file only contains headers but no data rows.";
    }
    
    $result['details']['sample_rows'] = $sample_data;
    $result['details']['line_count'] = $line_count;
    
    fclose($handle);
    return $result;
}

if (!empty($userID && $userPass)) {
    echo "<h3>Sync Tracking Numbers for Orders</h3>"
        . "<h5>This feature allows bulk updating of tracking information and order status. <a href='" . $template_url . "' download>Download CSV Template</a></h5>";
    if (!empty($_FILES)) {
        $enableimport = true;
        //echo "<p>File upload function is now running!</p>";
        
        try {
                $uploadDIR = wp_get_upload_dir();
            if (is_wp_error($uploadDIR)) {
                throw new Exception("Failed to get WordPress upload directory: " . $uploadDIR->get_error_message());
            }
            
            $uploadDIR = $uploadDIR["path"];
            $currentDir = getcwd();
            
            $errors = []; // Store all foreseen and unforseen errors here
            $fileExtensions = ['csv']; // Get all the file extensions
            
            if (!isset($_FILES['trackingCSV'])) {
                throw new Exception("No file was uploaded or the upload failed. Check PHP upload limits and permissions.");
            }
            
            $fileName = $_FILES['trackingCSV']['name'];
            $fileSize = $_FILES['trackingCSV']['size'];
            $fileTmpName = $_FILES['trackingCSV']['tmp_name'];
            $fileType = $_FILES['trackingCSV']['type'];
            
            if (empty($fileName)) {
                throw new Exception("The uploaded file has no name.");
            }
            
            $tmp = explode('.', $fileName);
            $fileExtension = strtolower(end($tmp));
            $uploadPath = $uploadDIR . DIRECTORY_SEPARATOR . basename($fileName);
            
            // Log the file details for debugging
            $upload_info = array(
                'file_name' => $fileName,
                'file_size' => $fileSize,
                'file_tmp_name' => $fileTmpName,
                'file_type' => $fileType,
                'file_extension' => $fileExtension,
                'upload_path' => $uploadPath,
                'upload_dir' => $uploadDIR
            );
        //var_dump($fileTmpName);
        //var_dump($uploadPath);

            // Validate file extension
            if (!in_array($fileExtension, $fileExtensions)) {
                $errors[] = '<p>This file extension is not allowed. Please upload a CSV file</p>';
            }

            // Validate file size
            if ($fileSize > 8000000) {
                $errors[] = '<p>This file is more than 8MB. Sorry, it has to be less than or equal to 8MB</p>';
            }
            
            // Check if file exists
            if (!file_exists($fileTmpName)) {
                throw new Exception("Uploaded file does not exist in temporary directory: $fileTmpName");
            }

            if (empty($errors)) {
                // Verify upload directory is writable
                if (!is_writable($uploadDIR)) {
                    throw new Exception("Upload directory is not writable: $uploadDIR");
                }
                
                $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
                
                if (!$didUpload) {
                    throw new Exception("Failed to move uploaded file from temp location to target directory. Check permissions. Upload error code: " . $_FILES['trackingCSV']['error']);
                }

                if ($didUpload) {
                    echo '<p>The file ' . basename($fileName) . ' has been uploaded</p>';
                    
                    // Validate the CSV file structure
                    $csv_validation = fm_validate_csv($uploadPath);
                    
                    if (!$csv_validation['valid']) {
                        echo '<div class="notice notice-error" style="padding: 15px; margin: 15px 0; border-left: 4px solid #dc3545;">';
                        echo '<h3>CSV Validation Errors</h3>';
                        echo '<ul style="margin-left: 20px; list-style-type: disc;">';
                        foreach ($csv_validation['errors'] as $error) {
                            echo '<li>' . esc_html($error) . '</li>';
                        }
                        echo '</ul>';
                        
                        // Show sample of the file for debugging
                        if (!empty($csv_validation['details'])) {
                            echo '<h4>CSV File Details</h4>';
                            echo '<pre style="background: #f5f5f5; padding: 10px; overflow: auto; max-height: 200px;">';
                            print_r($csv_validation['details']);
                            echo '</pre>';
                        }
                        echo '</div>';
                        
                        // Don't proceed with processing if validation failed
                        throw new Exception("CSV validation failed. Please fix the errors listed above and try again.");
                    }
                    
                    // Check if file is readable after upload
                    if (!is_readable($uploadPath)) {
                        throw new Exception("The uploaded file is not readable: $uploadPath");
                    }
                    
                    // Open the file for reading with error handling
                    $handle = fopen($uploadPath, "r");
                    if ($handle === false) {
                        throw new Exception("Failed to open the CSV file for reading: $uploadPath");
                    }
                    
                    $i = 0;
                    $tracking_data = array(); // Initialize tracking data array
                    $cols = array(); // Initialize columns array
                    
                    // Read the CSV file line by line
                    while (($line = fgetcsv($handle)) !== false) {
                    if ($i == 0) {
                        $c = 0;
                        $required_headers = array('ordernumber', 'trackingid');
                        $missing_headers = array();
                        
                        foreach ($line as $col) {
                            $cols[$c] = strtolower(trim($col)); // Normalize header names
                            $c++;
                        }
                        
                        // Validate required headers
                        foreach ($required_headers as $required) {
                            if (!in_array($required, $cols)) {
                                $missing_headers[] = $required;
                            }
                        }
                        
                        if (!empty($missing_headers)) {
                            echo '<div class="notice notice-error" style="padding: 10px; margin: 10px 0;"><p><strong>CSV Format Error:</strong> 
                                Your CSV file is missing the following required columns: <code>' . implode('</code>, <code>', $missing_headers) . '</code><br>
                                Please use the template provided or ensure your CSV has these column headers.</p>
                                <p>Found headers: <code>' . implode('</code>, <code>', $cols) . '</code></p>
                            </div>';
                            fclose($handle);
                            break;
                        }
                    } else if ($i > 0) {
                        $c = 0;
                        foreach ($line as $col) {
                            $tracking_data[$i][$cols[$c]] = $col;
                            $c++;
                        }
                    }
                    $i++;
                }
                fclose($handle);
                //echo "inital loop good<br>";
                //echo "<pre>";

                foreach ($tracking_data as $tracking_row) {
                    // Check if we're using the old 'orderid' column or new 'ordernumber' column
                    $orderNum = isset($tracking_row['ordernumber']) ? $tracking_row['ordernumber'] : 
                                (isset($tracking_row['orderid']) ? $tracking_row['orderid'] : '');
                    $trackingNum = $tracking_row['trackingid'];
                    
                    // Get additional fields if they exist in the CSV
                    $provider = isset($tracking_row['provider']) ? $tracking_row['provider'] : 'Fulfillmen';
                    $date_shipped = isset($tracking_row['date_shipped']) ? $tracking_row['date_shipped'] : date('Y-m-d');
                    $status = isset($tracking_row['status']) ? $tracking_row['status'] : 'Shipped';
                    $notes = isset($tracking_row['notes']) ? $tracking_row['notes'] : '';
                    
                    // Clean up order number by removing whitespace and optional prefixes
                    $orderNum = preg_replace('/\s+/', '', $orderNum);
                    $cleanOrderNum = preg_replace('/^[#WCFMwcfm-]+/', '', $orderNum); // Remove common prefixes
                    
                    // Try to find order by order number
                    $found = false;
                    $order_id = null;
                    
                    // First try to find by meta key _order_number (common in some shops)
                    if (function_exists('wc_get_orders')) {
                        $orders = wc_get_orders(array('meta_key' => '_order_number', 'meta_value' => $cleanOrderNum));
                        
                        if (!empty($orders)) {
                            $found = true;
                            foreach ($orders as $neworderid) {
                                $order_id = method_exists($neworderid, 'get_id') ? $neworderid->get_id() : $neworderid->id;
                                // Process this order
                                processOrderTracking($order_id, $orderNum, $trackingNum, $provider, $date_shipped, $status, $notes);
                            }
                        }
                    }
                    
                    // If not found, try looking up by order meta fields
                    if (!$found) {
                        // Query the database directly to find orders with matching order number
                        global $wpdb;
                        
                        // Try to find by meta value for _order_number
                        $meta_orders = $wpdb->get_col(
                            $wpdb->prepare(
                                "SELECT post_id FROM {$wpdb->prefix}postmeta 
                                WHERE meta_key IN ('_order_number', '_order_number_formatted') 
                                AND meta_value = %s",
                                $cleanOrderNum
                            )
                        );
                        
                        if (!empty($meta_orders)) {
                            $found = true;
                            foreach ($meta_orders as $post_id) {
                                // Process this order
                                processOrderTracking($post_id, $orderNum, $trackingNum, $provider, $date_shipped, $status, $notes);
                            }
                        }
                    }
                    
                    // If still not found, try by direct order ID/number
                    if (!$found && function_exists('wc_get_order')) {
                        // Try to load directly by ID or order number
                        try {
                            // Try original order number first
                            $order = wc_get_order($orderNum);
                            if (!$order) {
                                // Try clean number without prefixes
                                $order = wc_get_order($cleanOrderNum);
                            }
                            
                            if ($order) {
                                $order_id = method_exists($order, 'get_id') ? $order->get_id() : $order->id;
                                $found = true;
                                // Process this order
                                processOrderTracking($order_id, $orderNum, $trackingNum, $provider, $date_shipped, $status, $notes);
                            }
                        } catch (Exception $e) {
                            // Order not found, continue to next approach
                        }
                    }
                    
                    // If still not found, display detailed error
                    if (!$found) {
                        echo "<p class='error' style='color: #dc3545; background: #f8d7da; padding: 10px; border-left: 4px solid #dc3545;'>
                            <strong>Order not found:</strong> {$orderNum} - No corresponding WooCommerce order could be found.<br>
                            <strong>Details:</strong><br>
                            - Original Order #: {$orderNum}<br>
                            - Cleaned Order #: {$cleanOrderNum}<br>
                            - Tracking #: {$trackingNum}<br>
                            Please verify the order number exists in your WooCommerce system.
                        </p>";
                        
                        // Increment the failure counter
                        if (!isset($GLOBALS['fm_tracking_failure'])) {
                            $GLOBALS['fm_tracking_failure'] = 0;
                        }
                        $GLOBALS['fm_tracking_failure']++;
                    }
                }
                
                // Display summary after processing all rows
                $success_count = isset($GLOBALS['fm_tracking_success']) ? $GLOBALS['fm_tracking_success'] : 0;
                $failure_count = isset($GLOBALS['fm_tracking_failure']) ? $GLOBALS['fm_tracking_failure'] : 0;
                
                echo "<hr><div class='processing-summary' style='margin: 20px 0; padding: 15px; background: #f0f0f1; border-radius: 5px;'>";
                echo "<h3>Processing Summary:</h3>";
                echo "<p><strong>Total CSV rows:</strong> " . count($tracking_data) . "</p>";
                echo "<p><strong>Successfully updated:</strong> {$success_count} orders</p>";
                echo "<p><strong>Failed to update:</strong> {$failure_count} orders</p>";
                echo "</div>";
            } else {
                echo '<div class="notice notice-error" style="padding: 10px; margin: 10px 0;"><p><strong>Error:</strong> Failed to upload CSV file. Please check file permissions and try again.</p></div>';
            }
        } else {
            echo '<div class="notice notice-error" style="padding: 10px; margin: 10px 0;"><p><strong>Validation Errors:</strong></p><ul style="list-style-type: disc; margin-left: 20px;">';
            foreach ($errors as $error) {
                echo '<li>' . $error . '</li>';
            }
            echo '</ul></div>';
        }

        } catch (Exception $e) {
            // Log the detailed error for administrators
            $error_data = array(
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString(),
                'upload_info' => isset($upload_info) ? $upload_info : 'No upload info available',
                'POST' => $_POST,
                'FILES' => $_FILES
            );
            
            // If we have an uploaded file, try to read its contents for debugging
            if (isset($uploadPath) && file_exists($uploadPath) && is_readable($uploadPath)) {
                $error_data['csv_content'] = array();
                $handle = @fopen($uploadPath, 'r');
                if ($handle !== false) {
                    $line_count = 0;
                    while (($line = fgetcsv($handle)) !== false && $line_count < 10) {
                        $error_data['csv_content'][] = $line;
                        $line_count++;
                    }
                    fclose($handle);
                }
            }
            
            fm_log_error($e->getMessage(), $error_data);
            
            echo '<div class="notice notice-error" style="padding: 10px; margin: 10px 0;">
                <p><strong>Critical Error:</strong> An error occurred while processing your CSV file. Please see the detailed error information above.</p>
            </div>';
        }
        
        //here ends the for each loop
        echo "<br><a href='#' onclick='history.go(-1);' class='button-secondary'>Back</a>";

    } else { //Printing the Form
        ?>
        <style>
            .fulfillmen-form-container { background: #fff; padding: 20px; border: 1px solid #e5e5e5; border-radius: 3px; max-width: 800px; }
            .fulfillmen-form-container h4 { margin-top: 0; }
            .fulfillmen-instructions { background: #f9f9f9; padding: 15px; border-left: 4px solid #2271b1; margin-bottom: 20px; }
            .fulfillmen-instructions ul { list-style-type: disc; padding-left: 20px; }
            .fulfillmen-file-input { margin-bottom: 15px; }
            .fulfillmen-submit { margin-top: 10px; }
            .csv-example { font-family: monospace; background: #f5f5f5; padding: 10px; overflow: auto; }
        </style>
        
        <div class="fulfillmen-form-container">
            <h4>Bulk Upload Tracking Information</h4>
            
            <div class="fulfillmen-instructions">
                <p><strong>Instructions:</strong></p>
                <ul>
                    <li>Prepare a CSV file with the following columns: <code>ordernumber</code>, <code>trackingid</code></li>
                    <li>Optional columns: <code>provider</code>, <code>date_shipped</code>, <code>status</code>, <code>notes</code></li>
                    <li>For <code>ordernumber</code>, use the WooCommerce order number (with or without prefix like #, WC-, etc.)</li>
                    <li>Default shipping provider is "Fulfillmen" if not specified</li>
                    <li>Date format should be YYYY-MM-DD (e.g., 2025-07-21)</li>
                    <li>Maximum file size: 8MB</li>
                </ul>
            </div>
            
            <div class="csv-example" style="display: none;">
                ordernumber,trackingid,provider,date_shipped,status,notes<br>
                WC-1001,TRACK12345,Fulfillmen,2025-07-21,Shipped,Package 1 of 1<br>
                #1002,TRACK67890,DHL,2025-07-21,Shipped,Express delivery
            </div>
            
            <form class="syncOrders" enctype="multipart/form-data" action="" method="post">
                <div class="fulfillmen-file-input">
                    <p><strong>Select your CSV file:</strong></p>
                    <input type="file" name="trackingCSV" required accept=".csv" />
                </div>
                
                <div class="fulfillmen-submit">
                    <button type="submit" class="button button-primary">Upload and Process Tracking Information</button>
                    <a href="<?php echo esc_url($template_url); ?>" download class="button button-secondary" style="margin-left: 10px;">Download CSV Template</a>
                </div>
            </form>
        </div>
        <?php
    }
} else {
    echo '<div class="notice notice-error"><p><strong>Authentication Error:</strong> Invalid username and/or password. Please check your Fulfillmen credentials in the settings.</p></div>';
}
