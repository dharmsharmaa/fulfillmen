<?php
/**
 * Debug panel for Fulfillmen plugin
 *
 * This file provides a debug panel that shows PHP errors, cron issues, and other debugging information
 *
 * @link       www.dhairyasharma.com
 * @since      1.4.8
 *
 * @package    Fulfillmen
 * @subpackage Fulfillmen/admin/partials
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;
$prefix = 'fulfillmen_';

// Handle debug actions
if (isset($_POST['clear_debug_logs'])) {
    $admin_instance = new Fulfillmen_Admin('fulfillmen', '1.4.8');
    $admin_instance->fulfillmen_clear_debug_log();
    echo '<div class="notice notice-success"><p>Debug logs cleared successfully.</p></div>';
}

// Get debug logs
$admin_instance = new Fulfillmen_Admin('fulfillmen', '1.4.8');
$debug_logs = $admin_instance->fulfillmen_get_debug_log('', 20); // Get last 20 entries from all logs

?>

<div class="fulfillmen-admin-page">
    <h3>Debug Panel</h3>
    <p>This panel shows PHP errors, cron execution issues, and other debugging information from the Fulfillmen plugin.</p>
    
    <!-- Debug Controls -->
    <div class="debug-controls" style="margin: 20px 0; padding: 15px; border: 1px solid #ddd; background: #f9f9f9;">
        <h4>Debug Controls</h4>
        <form method="post" style="display: inline;">
            <input type="submit" name="clear_debug_logs" value="Clear Debug Logs" class="button button-secondary" onclick="return confirm('Are you sure you want to clear all debug logs?');">
        </form>
        
        <p style="margin-top: 10px;">
            <strong>Debug Status:</strong> 
            <?php if (defined('WP_DEBUG') && WP_DEBUG): ?>
                <span style="color: green;">✓ WP_DEBUG is enabled</span>
            <?php else: ?>
                <span style="color: orange;">⚠ WP_DEBUG is disabled</span>
            <?php endif; ?>
        </p>
        
        <p>
            <strong>Current Memory Usage:</strong> <?php echo size_format(memory_get_usage(true)); ?><br>
            <strong>Peak Memory Usage:</strong> <?php echo size_format(memory_get_peak_usage(true)); ?><br>
            <strong>PHP Version:</strong> <?php echo PHP_VERSION; ?>
        </p>
    </div>

    <!-- Cron Status -->
    <div class="cron-status" style="margin: 20px 0; padding: 15px; border: 1px solid #ddd; background: #f9f9f9;">
        <h4>Cron Job Status</h4>
        <table class="widefat">
            <thead>
                <tr>
                    <th>Cron Job</th>
                    <th>Next Scheduled</th>
                    <th>Interval</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $cron_jobs = array(
                    'fulfillmen_cron' => 'Tracking Updates',
                    'fulfillmen_orders_cron' => 'Order Processing'
                );
                
                foreach ($cron_jobs as $hook => $description):
                    $next_scheduled = wp_next_scheduled($hook);
                    $status_color = $next_scheduled ? 'green' : 'red';
                    $status_text = $next_scheduled ? 'Active' : 'Not Scheduled';
                ?>
                <tr>
                    <td><?php echo esc_html($description); ?></td>
                    <td>
                        <?php if ($next_scheduled): ?>
                            <?php echo date('Y-m-d H:i:s', $next_scheduled); ?><br>
                            <small>(<?php echo human_time_diff($next_scheduled); ?> from now)</small>
                        <?php else: ?>
                            <em>Not scheduled</em>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php 
                        if ($next_scheduled) {
                            $schedules = wp_get_schedules();
                            $cron_events = _get_cron_array();
                            foreach ($cron_events as $timestamp => $cron) {
                                if (isset($cron[$hook])) {
                                    foreach ($cron[$hook] as $event) {
                                        if (isset($schedules[$event['schedule']])) {
                                            echo esc_html($schedules[$event['schedule']]['display']);
                                        }
                                    }
                                    break 2;
                                }
                            }
                        } else {
                            echo '<em>N/A</em>';
                        }
                        ?>
                    </td>
                    <td><span style="color: <?php echo $status_color; ?>;">●</span> <?php echo $status_text; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Debug Log Display -->
    <div class="debug-logs">
        <h4>Recent Debug Logs (Last 20 entries)</h4>
        
        <?php if (empty($debug_logs)): ?>
            <div class="notice notice-info">
                <p>No debug logs found. This is good - it means no errors have been detected recently.</p>
            </div>
        <?php else: ?>
            <div style="max-height: 500px; overflow-y: auto; border: 1px solid #ddd; background: #fff;">
                <?php foreach ($debug_logs as $log_entry): ?>
                    <div class="debug-entry" style="border-bottom: 1px solid #eee; padding: 15px; <?php echo (!empty($log_entry['debug_info']) && count(array_filter($log_entry['debug_info'], function($item) { return in_array($item['type'], ['PHP Error', 'Exception', 'Fatal Error', 'Database Error', 'API Error']); })) > 0) ? 'background: #ffebee;' : ''; ?>">
                        <div style="font-weight: bold; margin-bottom: 10px;">
                            <span style="color: #666;">[<?php echo esc_html($log_entry['timestamp']); ?>]</span>
                            <span style="text-transform: uppercase; color: #333;"><?php echo esc_html($log_entry['cron_type']); ?></span>
                            <span style="float: right; font-size: 12px; color: #666;">
                                Memory: <?php echo size_format($log_entry['memory_usage']); ?> / Peak: <?php echo size_format($log_entry['peak_memory']); ?>
                            </span>
                        </div>
                        
                        <?php if (!empty($log_entry['debug_info'])): ?>
                            <?php foreach ($log_entry['debug_info'] as $debug_item): ?>
                                <div class="debug-item" style="margin: 5px 0; padding: 8px; border-left: 3px solid <?php 
                                    switch($debug_item['type']) {
                                        case 'PHP Error':
                                        case 'Fatal Error':
                                        case 'Exception':
                                        case 'Database Error':
                                        case 'API Error':
                                            echo '#f44336';
                                            break;
                                        case 'Success':
                                            echo '#4caf50';
                                            break;
                                        case 'Info':
                                            echo '#2196f3';
                                            break;
                                        default:
                                            echo '#ff9800';
                                    }
                                ?>; background: #f9f9f9;">
                                    <strong style="color: <?php 
                                        switch($debug_item['type']) {
                                            case 'PHP Error':
                                            case 'Fatal Error':
                                            case 'Exception':
                                            case 'Database Error':
                                            case 'API Error':
                                                echo '#d32f2f';
                                                break;
                                            case 'Success':
                                                echo '#388e3c';
                                                break;
                                            case 'Info':
                                                echo '#1976d2';
                                                break;
                                            default:
                                                echo '#f57c00';
                                        }
                                    ?>;"><?php echo esc_html($debug_item['type']); ?>:</strong>
                                    <?php echo esc_html($debug_item['message']); ?>
                                    
                                    <?php if (isset($debug_item['file']) && isset($debug_item['line'])): ?>
                                        <br><small style="color: #666;">in <?php echo esc_html($debug_item['file']); ?> on line <?php echo esc_html($debug_item['line']); ?></small>
                                    <?php endif; ?>
                                    
                                    <?php if (isset($debug_item['trace'])): ?>
                                        <details style="margin-top: 5px;">
                                            <summary style="cursor: pointer; color: #666;">Stack Trace</summary>
                                            <pre style="font-size: 11px; background: #f0f0f0; padding: 10px; margin: 5px 0; overflow-x: auto;"><?php echo esc_html($debug_item['trace']); ?></pre>
                                        </details>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Manual Test Section -->
    <div class="manual-tests" style="margin: 20px 0; padding: 15px; border: 1px solid #ddd; background: #f9f9f9;">
        <h4>Manual Tests</h4>
        <p>Use these buttons to manually trigger cron jobs and test functionality:</p>
        
        <a href="<?php echo admin_url('admin.php?page=wc-settings&tab=fulfillmen&section=trackings&manual_test=tracking_cron'); ?>" 
           class="button button-secondary" 
           onclick="return confirm('This will manually run the tracking cron job. Continue?');">
           Test Tracking Cron
        </a>
        
        <a href="<?php echo admin_url('admin.php?page=wc-settings&tab=fulfillmen&section=orders&manual_test=orders_cron'); ?>" 
           class="button button-secondary"
           onclick="return confirm('This will manually run the orders cron job. Continue?');">
           Test Orders Cron
        </a>
    </div>
</div>

<?php
// Handle manual tests
if (isset($_GET['manual_test'])) {
    $admin_instance = new Fulfillmen_Admin('fulfillmen', '1.4.8');
    
    switch ($_GET['manual_test']) {
        case 'tracking_cron':
            echo '<div class="notice notice-info"><p>Running tracking cron manually...</p></div>';
            $admin_instance->fulfillmen_cron_function();
            echo '<div class="notice notice-success"><p>Tracking cron completed. Check debug logs above for details.</p></div>';
            break;
            
        case 'orders_cron':
            echo '<div class="notice notice-info"><p>Running orders cron manually...</p></div>';
            $admin_instance->fulfillmen_cron_function_orders();
            echo '<div class="notice notice-success"><p>Orders cron completed. Check debug logs above for details.</p></div>';
            break;
    }
    
    // Refresh the page after test to show updated logs
    echo '<script>setTimeout(function() { window.location.href = window.location.href.split("&manual_test=")[0]; }, 2000);</script>';
}
?>

<style>
.debug-entry:hover {
    background-color: #f5f5f5 !important;
}

.debug-item {
    font-family: 'Courier New', monospace;
    font-size: 13px;
}

.widefat th {
    background: #f1f1f1;
    font-weight: bold;
}

details summary {
    font-weight: bold;
    margin: 5px 0;
}

details[open] summary {
    margin-bottom: 10px;
}
</style>
