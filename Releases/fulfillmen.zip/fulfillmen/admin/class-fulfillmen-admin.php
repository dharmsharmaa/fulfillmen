<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       www.dhairyasharma.com
 * @since      1.0.0
 *
 * @package    Fulfillmen
 * @subpackage Fulfillmen/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Fulfillmen
 * @subpackage Fulfillmen/admin
 * @author     Dhairya Sharma <hello@dhairyasharma.com>
 */
class Fulfillmen_Admin
{

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version)
    {

        $this->plugin_name = $plugin_name;
        $this->version = $version;

    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Fulfillmen_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Fulfillmen_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/fulfillmen-admin.css', array(), $this->version, 'all');

    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Fulfillmen_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Fulfillmen_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/fulfillmen-admin.js', array('jquery'), $this->version, false);
    }
    /**
     * Load dependencies for additional WooCommerce settings
     *
     * @since    1.0.0
     * @access   private
     */

    public function fulfillmen_add_settings($settings)
    {
        $settings[] = include plugin_dir_path(dirname(__FILE__)) . 'admin/class-fulfillmen-wc-settings.php';
        return $settings;
    }

    //Adding custom Status

    public function register_my_new_order_statuses()
    {
        register_post_status('wc-fulfilled', array(
            'label' => _x('Fulfilled', 'Order status', 'woocommerce'),
            'public' => true,
            'exclude_from_search' => false,
            'show_in_admin_all_list' => true,
            'show_in_admin_status_list' => true,
            'label_count' => _n_noop('Fulfilled <span class="count">(%s)</span>', 'Fulfilled<span class="count">(%s)</span>', 'woocommerce'),
        ));
    }

    public function my_new_wc_order_statuses($order_statuses)
    {
        $order_statuses['wc-fulfilled'] = _x('Fulfilled', 'Order status', 'woocommerce');
        return $order_statuses;
    }

    public function my_new_wc_order_statuses2($order_statuses1)
    {
        $order_statuses1['wc-fminprocess'] = _x('Processing at Warehouse', 'Order status', 'woocommerce');
        return $order_statuses1;
    }
    //Adding custom Field to capture Tracking Number
    // Add a the metabox to Order edit pages
    public function add_postnord_meta_box()
    {
        function add_postnord_meta_box_content()
        {
            global $post;

            $value = get_post_meta($post->ID, '_postnord_field_data', true);

            echo '<input type="hidden" name="postnord_meta_field_nonce" value="' . wp_create_nonce() . '">
                <p style="border-bottom:solid 1px #eee;padding-bottom:13px;">
                <input type="text" style="width:250px;";" name="postnord_data_name" value="' . $value . '"></p>';
        }

        add_meta_box('postnord_field', __('Parcel ID', 'woocommerce'), 'add_postnord_meta_box_content', 'shop_order', 'side', 'core');

    }

// Save the field value from metabox content
    public function save_postnord_meta_box_field_value($post_id)
    {

        if (!isset($_POST['postnord_meta_field_nonce'])) {
            return $post_id;
        }

        $nonce = $_REQUEST['postnord_meta_field_nonce'];

        if (!wp_verify_nonce($nonce)) {
            return $post_id;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return $post_id;
        }

        if (!(current_user_can('edit_shop_order', $post_id) || current_user_can('edit_shop_order', $post_id))) {
            return $post_id;
        }

        update_post_meta($post_id, '_postnord_field_data', sanitize_text_field($_POST['postnord_data_name']));
    }

// Display post north tracking info under shipping address
    public function postnord_custom_field_display_admin_order_meta($order)
    {
        $postnord_value = $order->get_meta('_postnord_field_data');
        if (!empty($postnord_value)) {
            echo '<p><strong>' . __("Tracking ID", "woocommerce") . ':</strong> ' . $postnord_value . '</p>';
        }
    }

// Display post north tracking info under shipping address
 public function postnord_custom_field_display_customer_order_meta($order)
    {
        $prefix = 'fulfillmen_';
        $tracking_data = $order->get_meta('_postnord_field_data');
        $TrackingURl = get_option($prefix . 'customtrackingurl').$tracking_data;
        if (!empty($tracking_data)) {
            // Display the tracking information
            $tracking_info = '<address><span style="display: inline-block;font-style: normal;">Tracking Number: '.$tracking_data.' <a style="font-size: 10px;display: inline-block;vertical-align: middle;margin-left: 5px;" href="'.$TrackingURl.'" class="button" target="_blank">Track Your Order</a></span></address>';
            echo '<div style="border: 1px solid #cbd5e0;padding: 5px;border-radius: 5px;margin-bottom: 15px;"><h6>' . __('Tracking Information', 'woocommerce') . '</h6> ' . $tracking_info . '</div>';
        }
    }


// Display post north tracking info and urls on customer email
    //public function add_postnord_tracking_to_customer_complete_order_email($order, $sent_to_admin, $plain_text, $email)
    public function add_postnord_tracking_to_customer_complete_order_email($order)
    {

        $prefix = 'fulfillmen_';
        $TrackingURl = get_option($prefix . 'customtrackingurl');
        /*if ($sent_to_admin) {
        return;
        }*/
        // Exit

        $postnord_value = $order->get_meta('_postnord_field_data');

        if (!empty($postnord_value)) {
            $postnord_url = 'http://track.fulfillmen.com/';
            $tracking_url = $TrackingURl . $postnord_value;
            $title = __("Track Your Order", "woocommerce");
            $message = '<p><strong>' . __("Tracking ID", "woocommerce") . ':</strong> ' . $postnord_value . '</p>
            <p>' . sprintf(__("You can track your parcel %s ", "woocommerce"),
                // '<a href="' . $postnord_url . '" target="_blank">' . __("Tracking website", "woocommerce") . '</a>',
                '<a href="' . $tracking_url . '" target="_blank">' . __("here", "woocommerce") . '</a>.</p>');

            echo '<style>
        .tracking table {width: 100%; font-family: \'Helvetica Neue\', Helvetica, Roboto, Arial, sans-serif;
            color: #737373; border: 1px solid #e4e4e4; margin-bottom:8px;}
        .tracking table td{text-align: left; border-top-width: 4px; color: #737373; border: 1px solid #e4e4e4;
            padding: 12px; padding-bottom: 4px;}
        </style>
        <div class="tracking">
        <h2>' . $title . '</h2>
        <table cellspacing="0" cellpadding="6">
            <tr><td>' . $message . '</td></tr>
        </table></div><br>';
        } 
    }

    //Setup Cron for Tracking Update

    public function fulfillmen_check_every_3_hours($schedules)
    {
        $schedules['every_three_hours'] = array(
            'interval' => 10800, // 3 hours
            'display' => __('Every 3 hours'),
        );
        
        // Add schedules for order sync functionality
        $schedules['every_five_minutes'] = array(
            'interval' => 300, // 5 minutes (practical "instant")
            'display' => __('Every 5 minutes'),
        );
        
        $schedules['every_two_hours'] = array(
            'interval' => 7200, // 2 hours
            'display' => __('Every 2 hours'),
        );
        
        $schedules['every_eight_hours'] = array(
            'interval' => 28800, // 8 hours
            'display' => __('Every 8 hours'),
        );
        
        return $schedules;
    }

    public function fulfillmen_schedule_cron()
    {
        if (!wp_next_scheduled('fulfillmen_cron')) {
            wp_schedule_event(time(), 'every_three_hours', 'fulfillmen_cron');
        }

    }

    public function fulfillmen_schedule_cron_for_orders()
    {
        // Clear any existing scheduled event first to avoid duplicates
        $timestamp = wp_next_scheduled('fulfillmen_orders_cron');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'fulfillmen_orders_cron');
        }
        
        // Schedule new event with current settings
        $orderSyncDuration = get_option('fulfillmen_order_sync_duration', '3'); // Default to 'After 8 Hours'
        
        // Define schedule names based on duration setting
        $schedules = array(
            '1' => 'every_five_minutes',    // Instant (using 5 minutes for practical purposes)
            '2' => 'every_two_hours',       // After 2 hours
            '3' => 'every_eight_hours',     // After 8 hours (default)
            '4' => 'daily',                 // After 24 hours (WordPress built-in)
        );
        
        $schedule = isset($schedules[$orderSyncDuration]) ? $schedules[$orderSyncDuration] : 'every_eight_hours';
        wp_schedule_event(time(), $schedule, 'fulfillmen_orders_cron');
    }

    public function fulfillmen_clear_scheduled_cron_orders()
    {
        $timestamp = wp_next_scheduled('fulfillmen_orders_cron');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'fulfillmen_orders_cron');
        }
    }

    public function fulfillmen_cron_function()
    {
        // Start error capturing for debug
        $debug_info = array();
        $original_error_handler = set_error_handler(function($severity, $message, $file, $line) use (&$debug_info) {
            $debug_info[] = array(
                'type' => 'PHP Error',
                'severity' => $severity,
                'message' => $message,
                'file' => basename($file),
                'line' => $line,
                'timestamp' => current_time('mysql')
            );
        });

        try {
            //Trigger Tracking updates
            ob_start(); // Capture any output
            include plugin_dir_path(dirname(__FILE__)) . 'admin/partials/fulfillmen-admin-trackings-update.php';
            $output = ob_get_clean();
            
            if (!empty($output)) {
                $debug_info[] = array(
                    'type' => 'Output',
                    'message' => $output,
                    'timestamp' => current_time('mysql')
                );
            }
            
        } catch (Exception $e) {
            $debug_info[] = array(
                'type' => 'Exception',
                'message' => $e->getMessage(),
                'file' => basename($e->getFile()),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString(),
                'timestamp' => current_time('mysql')
            );
        } catch (Error $e) {
            $debug_info[] = array(
                'type' => 'Fatal Error',
                'message' => $e->getMessage(),
                'file' => basename($e->getFile()),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString(),
                'timestamp' => current_time('mysql')
            );
        } finally {
            // Restore original error handler
            if ($original_error_handler) {
                restore_error_handler();
            }
            
            // Log debug info if there are any issues
            if (!empty($debug_info)) {
                $this->fulfillmen_log_cron_debug('tracking_cron', $debug_info);
            }
        }
        /*$CronBody = "Cron Ran at:".date('r')."\n".$TrackResponse;
    wp_mail('it@fulfillmen.com', 'Cron Worked', $CronBody);*/
    }

    public function fulfillmen_cron_function_orders()
    {
        // Start error capturing for debug
        $debug_info = array();
        $original_error_handler = set_error_handler(function($severity, $message, $file, $line) use (&$debug_info) {
            $debug_info[] = array(
                'type' => 'PHP Error',
                'severity' => $severity,
                'message' => $message,
                'file' => basename($file),
                'line' => $line,
                'timestamp' => current_time('mysql')
            );
        });

        try {
            //Trigger Order updates
            ob_start(); // Capture any output
            include plugin_dir_path(dirname(__FILE__)) . 'admin/partials/fulfillmen-admin-orders-update.php';
            $output = ob_get_clean();
            
            if (!empty($output)) {
                $debug_info[] = array(
                    'type' => 'Output',
                    'message' => $output,
                    'timestamp' => current_time('mysql')
                );
            }
            
        } catch (Exception $e) {
            $debug_info[] = array(
                'type' => 'Exception',
                'message' => $e->getMessage(),
                'file' => basename($e->getFile()),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString(),
                'timestamp' => current_time('mysql')
            );
        } catch (Error $e) {
            $debug_info[] = array(
                'type' => 'Fatal Error',
                'message' => $e->getMessage(),
                'file' => basename($e->getFile()),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString(),
                'timestamp' => current_time('mysql')
            );
        } finally {
            // Restore original error handler
            if ($original_error_handler) {
                restore_error_handler();
            }
            
            // Log debug info if there are any issues
            if (!empty($debug_info)) {
                $this->fulfillmen_log_cron_debug('orders_cron', $debug_info);
            }
        }
    }

    public function fulfillmen_webhook_order_collection($order)
    {
        global $wpdb, $ordersTable, $credentials, $storeName;
        $prefix = 'fulfillmen_';
        $debug_info = array();
        $TrackResponse = '';
        
        // Start error capturing
        $original_error_handler = set_error_handler(function($severity, $message, $file, $line) use (&$debug_info) {
            $debug_info[] = array(
                'type' => 'PHP Error',
                'severity' => $severity,
                'message' => $message,
                'file' => basename($file),
                'line' => $line,
                'timestamp' => current_time('mysql')
            );
        });

        try {
            $ifWebhook = get_option($prefix . 'webhook_fw_orders');
            if ($ifWebhook == 'yes') {
                $Body = "First Sequence completed at at:" . date('r') . "\n";
                $debug_info[] = array('type' => 'Info', 'message' => 'Webhook processing started', 'timestamp' => current_time('mysql'));

                ob_start();
                include_once plugin_dir_path(dirname(__FILE__)) . 'admin/partials/fulfillmen-admin-orders-webhook.php';
                $output = ob_get_clean();
                
                if (!empty($output)) {
                    $debug_info[] = array('type' => 'Webhook Include Output', 'message' => $output, 'timestamp' => current_time('mysql'));
                }

                $Body = "Second Sequence completed at at:" . date('r') . "\n";
                $debug_info[] = array('type' => 'Info', 'message' => 'About to process order with wf_process_orders', 'timestamp' => current_time('mysql'));

                $orderid = wc_get_order($order);
                if (!$orderid) {
                    throw new Exception("Invalid order ID: " . $order);
                }

                $response = wf_process_orders($orderid, 'http://wms.fulfillmen.com/webservice/APIWebService.asmx', $credentials, $storeName);
                
                if (is_wp_error($response)) {
                    $error_message = $response->get_error_message();
                    $debug_info[] = array('type' => 'WP Error', 'message' => $error_message, 'timestamp' => current_time('mysql'));
                    $TrackResponse .= json_encode(array('success' => $error_message));
                    $Body = "Third Sequence failed at at:" . date('r') . "\n" . $TrackResponse;
                } else {
                    $Body = "Third Sequence Completed at at:" . date('r') . "\n";
                    $debug_info[] = array('type' => 'Info', 'message' => 'Order processing completed successfully', 'timestamp' => current_time('mysql'));

                    $res = json_decode($response);
                    
                    if (json_last_error() !== JSON_ERROR_NONE) {
                        throw new Exception("JSON decode error: " . json_last_error_msg());
                    }

                    if ($res && isset($res->success) && $res->success == "success") {
                        $Body = "Fourth Sequence completed at at:" . date('r') . "\n";
                        $debug_info[] = array('type' => 'Success', 'message' => 'Order processed successfully: ' . $res->OrderNo, 'timestamp' => current_time('mysql'));

                        $sql = "INSERT INTO $ordersTable (OrderNumber,FulfillmenOrderNum,FMOrderStatus,FMOrderTracking,isSynced) values('$res->CsRefNo','$res->OrderNo','Draft','NA','0')";
                        $result = $wpdb->query($sql);
                        
                        if ($result === false) {
                            $debug_info[] = array('type' => 'Database Error', 'message' => $wpdb->last_error, 'timestamp' => current_time('mysql'));
                        }

                        update_post_meta($order, 'fmDraftSynced', 'yes');
                        update_post_meta($order, 'fmDraftOrderNumber', $res->OrderNo);
                        $TrackResponse .= "Order Processed: " . $res->OrderNo;
                        $Body = "Final Sequence completed at at:" . date('r') . "\n" . $TrackResponse;
                    } else {
                        $error_info = isset($res->Info) ? $res->Info : 'Unknown error';
                        $debug_info[] = array('type' => 'API Error', 'message' => $error_info, 'timestamp' => current_time('mysql'));
                        $TrackResponse .= "Error Occured: " . $error_info;
                        $Body = "Final Sequence failed at at:" . date('r') . "\n" . $TrackResponse;
                    }
                }
            } else {
                $debug_info[] = array('type' => 'Info', 'message' => 'Webhook processing disabled', 'timestamp' => current_time('mysql'));
                $Body = "First Sequence completed at at:" . date('r') . "\n";
                return;
            }
        } catch (Exception $e) {
            $debug_info[] = array(
                'type' => 'Exception',
                'message' => $e->getMessage(),
                'file' => basename($e->getFile()),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString(),
                'timestamp' => current_time('mysql')
            );
        } catch (Error $e) {
            $debug_info[] = array(
                'type' => 'Fatal Error',
                'message' => $e->getMessage(),
                'file' => basename($e->getFile()),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString(),
                'timestamp' => current_time('mysql')
            );
        } finally {
            // Restore original error handler
            if ($original_error_handler) {
                restore_error_handler();
            }
            
            // Log debug info
            if (!empty($debug_info)) {
                $this->fulfillmen_log_cron_debug('webhook_orders', $debug_info);
            }
        }
    }

    /**
     * Log cron debug information
     * 
     * @param string $cron_type Type of cron (orders_cron, tracking_cron)
     * @param array $debug_info Array of debug information
     */
    public function fulfillmen_log_cron_debug($cron_type, $debug_info) {
        $option_key = 'fulfillmen_' . $cron_type . '_debug_log';
        
        // Get existing log (keep last 50 entries)
        $existing_log = get_option($option_key, array());
        if (!is_array($existing_log)) {
            $existing_log = array();
        }
        
        // Add new debug info with timestamp
        $log_entry = array(
            'timestamp' => current_time('mysql'),
            'cron_type' => $cron_type,
            'debug_info' => $debug_info,
            'memory_usage' => memory_get_usage(true),
            'peak_memory' => memory_get_peak_usage(true)
        );
        
        array_unshift($existing_log, $log_entry);
        
        // Keep only last 50 entries
        $existing_log = array_slice($existing_log, 0, 50);
        
        // Save back to options
        update_option($option_key, $existing_log);
        
        // If WP_DEBUG is enabled, also log to error log
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Fulfillmen ' . $cron_type . ' Debug: ' . print_r($debug_info, true));
        }
    }
    
    /**
     * Get debug log for display in admin
     * 
     * @param string $cron_type Type of cron (orders_cron, tracking_cron)
     * @param int $limit Number of entries to retrieve
     * @return array Debug log entries
     */
    public function fulfillmen_get_debug_log($cron_type = '', $limit = 10) {
        if (empty($cron_type)) {
            // Get both logs
            $orders_log = get_option('fulfillmen_orders_cron_debug_log', array());
            $tracking_log = get_option('fulfillmen_tracking_cron_debug_log', array());
            
            // Merge and sort by timestamp
            $combined_log = array_merge($orders_log, $tracking_log);
            usort($combined_log, function($a, $b) {
                return strtotime($b['timestamp']) - strtotime($a['timestamp']);
            });
            
            return array_slice($combined_log, 0, $limit);
        } else {
            $option_key = 'fulfillmen_' . $cron_type . '_debug_log';
            $log = get_option($option_key, array());
            return array_slice($log, 0, $limit);
        }
    }
    
    /**
     * Clear debug logs
     * 
     * @param string $cron_type Type of cron to clear, or empty for all
     */
    public function fulfillmen_clear_debug_log($cron_type = '') {
        if (empty($cron_type)) {
            delete_option('fulfillmen_orders_cron_debug_log');
            delete_option('fulfillmen_tracking_cron_debug_log');
            delete_option('fulfillmen_webhook_orders_debug_log');
        } else {
            $option_key = 'fulfillmen_' . $cron_type . '_debug_log';
            delete_option($option_key);
        }
    }
    
    /**
     * Force schedule the orders cron (for debugging/manual trigger)
     */
    public function fulfillmen_force_schedule_orders_cron() {
        // Clear any existing cron first
        $this->fulfillmen_clear_scheduled_cron_orders();
        
        // Force schedule with current settings
        $this->fulfillmen_schedule_cron_for_orders();
        
        return wp_next_scheduled('fulfillmen_orders_cron') ? true : false;
    }

}
